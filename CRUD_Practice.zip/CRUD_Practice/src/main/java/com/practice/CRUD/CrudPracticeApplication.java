package com.practice.CRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudPracticeApplication.class, args);
	}

}
